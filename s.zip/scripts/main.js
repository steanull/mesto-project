const popup = document.querySelector('.popup');
const popupCloseBtn = popup.querySelector('.popup__close');
const editProfileBtn = document.querySelector('.profile-info__button');
const editProfileJob = document.querySelector('.profile-info__subtitle');
const editProfileName = document.querySelector('.profile-info__title');
const formCardElement = document.querySelector('.card-form');
const formEditElement = document.querySelector('.edit-form');
const nameInput = formEditElement.querySelector('.edit-name');
const jobInput = formEditElement.querySelector('.edit-job');
const nameCardInput = formCardElement.querySelectorAll('.card-name');
const ImageCardInput = formCardElement.querySelectorAll('.card-image');
const elementsList = document.querySelector('.elements__list');
const popupCard = document.querySelector('.popup-card');
const addCardBtn = document.querySelector('.profile__button');
const popupCardCloseBtn = popupCard.querySelector('.popup__close');

const initialCards = [
    {
        name: 'Архыз',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/arkhyz.jpg'
    },
    {
        name: 'Челябинская область',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/chelyabinsk-oblast.jpg'
    },
    {
        name: 'Иваново',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/ivanovo.jpg'
    },
    {
        name: 'Камчатка',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kamchatka.jpg'
    },
    {
        name: 'Холмогорский район',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kholmogorsky-rayon.jpg'
    },
    {
        name: 'Байкал',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/baikal.jpg'
    },
    {
        name: 'Камчатка',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kamchatka.jpg'
    },
    {
        name: 'Холмогорский район',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kholmogorsky-rayon.jpg'
    },
    {
        name: 'Байкал',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/baikal.jpg'
    }
];

function newCard(cardData) {
    const cardTemplate = document.querySelector('#element').content;
    const cardElement = cardTemplate.querySelector('.element').cloneNode(true);
    const cardTitle = cardElement.querySelector('.element__title');
    const cardImage = cardElement.querySelector('.element__image');
    cardTitle.textContent = cardData.name;
    cardImage.src = cardData.link;
    cardImage.alt = cardData.name;

    return cardElement;
}

function addCard(cardElement, cardContainer) {
    const card = newCard(cardElement);
    cardContainer.prepend(card);
}

initialCards.forEach((item) => {
    addCard(item, elementsList);
});


function formEditSubmitHandler (evt) {
    evt.preventDefault();
    if (nameInput.value && jobInput.value) {
        editProfileName.textContent = nameInput.value;
        editProfileJob.textContent = jobInput.value;
        console.log (jobInput.value);
        closePopup(popup);
    }
}

function formCardSubmitHandler (evt) {
    evt.preventDefault();
        addCard({
            name : nameCardInput.value,
            link : ImageCardInput.value
        }, elementsList)
        closePopup(popupCard);
}

formEditElement.addEventListener('submit', formEditSubmitHandler);
formCardElement.addEventListener('submit', formCardSubmitHandler);

function openPopup(element) {
    element.classList.add('popup_opened');
}

function closePopup(element) {
    element.classList.remove('popup_opened');
}

editProfileBtn.addEventListener('click', function () {
    openPopup(popup);
});

addCardBtn.addEventListener('click', function () {
    openPopup(popupCard);
});

popupCloseBtn.addEventListener('click', function(){
    closePopup(popup);
});

popupCardCloseBtn.addEventListener('click', function(){
    closePopup(popupCard);
});